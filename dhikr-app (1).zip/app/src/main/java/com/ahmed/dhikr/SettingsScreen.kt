package com.ahmed.dhikr

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SwitchRow(title: String, get: () -> Boolean, set: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var v by remember { mutableStateOf(get()) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = { v = it; set(it); refreshAll(ctx) })
    }
}

@Composable
fun StepRow(title: String, get: () -> Int, set: (Int) -> Unit, min: Int, max: Int, step: Int = 1, show: (Int) -> String = { "$it د" }) {
    val ctx = LocalContext.current
    var v by remember { mutableIntStateOf(get()) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), fontSize = 15.sp)
        OutlinedButton(
            onClick = { if (v - step >= min) { v -= step; set(v); refreshAll(ctx) } },
            modifier = Modifier.size(42.dp), contentPadding = PaddingValues(0.dp)
        ) { Text("−", fontSize = 20.sp) }
        Text(show(v), Modifier.width(96.dp), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold)
        OutlinedButton(
            onClick = { if (v + step <= max) { v += step; set(v); refreshAll(ctx) } },
            modifier = Modifier.size(42.dp), contentPadding = PaddingValues(0.dp)
        ) { Text("+", fontSize = 20.sp) }
    }
}

@Composable
fun TimeRow(title: String, get: () -> Int, set: (Int) -> Unit) {
    StepRow(title, get, { set(((it % 1440) + 1440) % 1440) }, 0, 1425, 15) { Fmt.hm(it) }
}

@Composable
fun AudioRow(title: String, get: () -> String?, set: (String?) -> Unit) {
    val ctx = LocalContext.current
    var cur by remember { mutableStateOf(get()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) { }
            set(uri.toString()); cur = uri.toString()
        }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Column(Modifier.weight(1f)) {
            Text(title)
            Text(if (cur == null) "صوت الجوال" else "ملف صوت خاص ✓", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
        }
        OutlinedButton(onClick = { launcher.launch(arrayOf("audio/*")) }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("اختيار") }
        if (cur != null) OutlinedButton(onClick = { set(null); cur = null }, contentPadding = PaddingValues(horizontal = 10.dp)) { Text("حذف") }
    }
}

private fun refreshAll(ctx: android.content.Context) {
    if (Prefs(ctx).enabled) DhikrService.start(ctx) else Scheduler.schedule(ctx)
    DhikrWidget.updateAll(ctx)
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val p = remember { Prefs(ctx) }
    var place by remember { mutableStateOf(p.placeName) }
    var mode by remember { mutableIntStateOf(p.mode) }
    var vol by remember { mutableFloatStateOf(p.volume) }
    var untilFajr by remember { mutableStateOf(p.sleepUntilFajr) }
    var openPrayer by remember { mutableIntStateOf(-1) }

    val locLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) {
            Loc.fetch(ctx) { ok ->
                place = p.placeName
                Toast.makeText(ctx, if (ok) "تم تحديد موقعك" else "تعذّر تحديد الموقع، اختر مدينتك من القائمة", Toast.LENGTH_LONG).show()
                refreshAll(ctx)
            }
        } else {
            Toast.makeText(ctx, "بدون إذن الموقع اختر مدينتك من القائمة", Toast.LENGTH_LONG).show()
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Section("التذكير الدوري") {
            SwitchRow("الصلاة على النبي ﷺ", { p.salawatOn }, { p.salawatOn = it })
            StepRow("كل", { p.salawatEvery }, { p.salawatEvery = it }, 1, 60)
            StepRow("كل (يوم الجمعة)", { p.fridaySalawatEvery }, { p.fridaySalawatEvery = it }, 1, 60)
            SwitchRow("الأذكار المتنوعة", { p.dhikrOn }, { p.dhikrOn = it })
            StepRow("كل", { p.dhikrEvery }, { p.dhikrEvery = it }, 1, 120)
        }

        Section("الصلاة") {
            SwitchRow("«الله أكبر، الله أكبر» عند دخول الوقت", { p.takbirOn }, { p.takbirOn = it })
            Text("السكوت وقت الصلاة (لكل صلاة):", fontSize = 14.sp)
            Prayer.names.forEachIndexed { i, name ->
                OutlinedButton(onClick = { openPrayer = if (openPrayer == i) -1 else i }, modifier = Modifier.fillMaxWidth()) {
                    Text("$name — يسكت بعد ${p.muteAfter(i)} د لمدة ${p.muteFor(i)} د")
                }
                if (openPrayer == i) {
                    StepRow("يبدأ السكوت بعد التكبير بـ", { p.muteAfter(i) }, { p.setMuteAfter(i, it) }, 0, 60)
                    StepRow("مدة السكوت", { p.muteFor(i) }, { p.setMuteFor(i, it) }, 0, 90)
                }
            }
        }

        Section("وقت النوم (بدون أصوات)") {
            SwitchRow("تفعيل وقت النوم", { p.sleepOn }, { p.sleepOn = it })
            TimeRow("يبدأ", { p.sleepStartMin }, { p.sleepStartMin = it })
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("ينتهي عند الفجر", Modifier.weight(1f))
                Switch(checked = untilFajr, onCheckedChange = { untilFajr = it; p.sleepUntilFajr = it; refreshAll(ctx) })
            }
            if (!untilFajr) TimeRow("ينتهي", { p.sleepEndMin }, { p.sleepEndMin = it })
        }

        Section("الورد والأذكار") {
            SwitchRow("تذكير الورد اليومي", { p.wirdOn }, { p.wirdOn = it })
            TimeRow("وقت التذكير", { p.wirdMin }, { p.wirdMin = it })
            SwitchRow("أذكار الصباح (بعد الفجر بـ 20 د)", { p.morningOn }, { p.morningOn = it })
            SwitchRow("أذكار المساء (بعد العصر بـ 20 د)", { p.eveningOn }, { p.eveningOn = it })
            SwitchRow("تذكير سورة الكهف يوم الجمعة", { p.kahfOn }, { p.kahfOn = it })
        }

        Section("الصوت") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("صوت", "اهتزاز", "سماعة فقط").forEachIndexed { i, s ->
                    Seg(s, mode == i, Modifier.weight(1f)) { mode = i; p.mode = i }
                }
            }
            Text("مستوى الصوت: ${(vol * 100).toInt()}٪", fontSize = 14.sp)
            Slider(value = vol, onValueChange = { vol = it }, onValueChangeFinished = { p.volume = vol }, valueRange = 0.2f..1f)
            AudioRow("الصلاة على النبي ﷺ", { p.uriSalawat }, { p.uriSalawat = it })
            AudioRow("التكبير", { p.uriTakbir }, { p.uriTakbir = it })
            AudioRow("الأذكار (ملف واحد لكل الأذكار)", { p.uriDhikr }, { p.uriDhikr = it })
            SwitchRow("دقة عالية في التوقيت (تظهر أيقونة منبه)", { p.precise }, { p.precise = it })
            OutlinedButton(onClick = { DhikrService.start(ctx, DhikrService.ACTION_TEST) }) { Text("🔊 تجربة") }
        }

        Section("الموقع (لحساب مواقيت الصلاة)") {
            Text("الحالي: $place", fontWeight = FontWeight.Bold)
            Button(onClick = {
                locLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
            }, modifier = Modifier.fillMaxWidth()) { Text("📍 تحديد موقعي تلقائياً") }
            Text("أو اختر مدينتك:", fontSize = 14.sp)
            Prayer.cities.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    row.forEach { c ->
                        Seg(c.name, place == c.name, Modifier.weight(1f)) {
                            p.lat = c.lat; p.lng = c.lng; p.placeName = c.name; place = c.name; refreshAll(ctx)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        Text("ذِكر — بدون إعلانات، بدون إنترنت، بدون جمع بيانات.", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
        Spacer(Modifier.height(8.dp))
    }
}
