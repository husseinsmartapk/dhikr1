package com.ahmed.dhikr

import com.batoulapps.adhan.CalculationMethod
import com.batoulapps.adhan.Coordinates
import com.batoulapps.adhan.PrayerTimes
import com.batoulapps.adhan.data.DateComponents
import java.util.Calendar

object Prayer {
    val names = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")

    data class City(val name: String, val lat: Double, val lng: Double)

    val cities = listOf(
        City("الأحساء", 25.3833, 49.5867),
        City("الرياض", 24.7136, 46.6753),
        City("مكة المكرمة", 21.4225, 39.8262),
        City("المدينة المنورة", 24.4672, 39.6111),
        City("جدة", 21.4858, 39.1925),
        City("الدمام", 26.4207, 50.0888),
        City("الخبر", 26.2172, 50.1971),
        City("الجبيل", 27.0112, 49.6583),
        City("الطائف", 21.2703, 40.4158),
        City("بريدة", 26.3260, 43.9750),
        City("حائل", 27.5114, 41.7208),
        City("تبوك", 28.3838, 36.5550),
        City("أبها", 18.2164, 42.5053),
        City("جازان", 16.8892, 42.5511),
        City("نجران", 17.4924, 44.1277),
        City("الباحة", 20.0129, 41.4677),
        City("عرعر", 30.9753, 41.0381),
        City("سكاكا", 29.9697, 40.2064)
    )

    /** prayer times (epoch ms, rounded to the minute) for the calendar day of [day] */
    fun times(p: Prefs, day: Calendar): List<Long> {
        val dc = DateComponents(day.get(Calendar.YEAR), day.get(Calendar.MONTH) + 1, day.get(Calendar.DAY_OF_MONTH))
        val pt = PrayerTimes(Coordinates(p.lat, p.lng), dc, CalculationMethod.UMM_AL_QURA.parameters)
        return listOf(pt.fajr, pt.dhuhr, pt.asr, pt.maghrib, pt.isha).map { ((it.time + 30_000L) / 60_000L) * 60_000L }
    }
}
