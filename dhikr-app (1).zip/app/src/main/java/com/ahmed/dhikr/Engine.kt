package com.ahmed.dhikr

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object Engine {
    const val MIN = 60_000L

    enum class Kind { TAKBIR, MORNING, EVENING, WIRD, WIRD_CHECK, KAHF, DHIKR, SALAWAT }
    data class Ev(val time: Long, val kind: Kind, val idx: Int = 0)

    fun startOfDay(t: Long): Calendar = Calendar.getInstance().apply {
        timeInMillis = t
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }

    private fun plusDays(c: Calendar, n: Int): Calendar = (c.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, n) }

    fun isFriday(t: Long): Boolean =
        Calendar.getInstance().apply { timeInMillis = t }.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY

    fun minuteOfDay(t: Long): Int {
        val c = Calendar.getInstance().apply { timeInMillis = t }
        return c.get(Calendar.HOUR_OF_DAY) * 60 + c.get(Calendar.MINUTE)
    }

    fun fixedEvents(p: Prefs, day: Calendar): List<Ev> {
        val d0 = day.timeInMillis
        val pr = Prayer.times(p, day)
        val out = mutableListOf<Ev>()
        if (p.takbirOn) pr.forEachIndexed { i, t -> out += Ev(t, Kind.TAKBIR, i) }
        if (p.morningOn) out += Ev(pr[0] + 20 * MIN, Kind.MORNING)
        if (p.eveningOn) out += Ev(pr[2] + 20 * MIN, Kind.EVENING)
        if (p.wirdOn) {
            out += Ev(d0 + p.wirdMin * MIN, Kind.WIRD)
            out += Ev(pr[3] - 30 * MIN, Kind.WIRD_CHECK)
        }
        if (p.kahfOn && day.get(Calendar.DAY_OF_WEEK) == Calendar.FRIDAY) out += Ev(d0 + 9 * 60 * MIN, Kind.KAHF)
        return out
    }

    fun salawatEvery(p: Prefs, t: Long): Int = if (isFriday(t)) p.fridaySalawatEvery else p.salawatEvery

    fun periodicDue(p: Prefs, t: Long): List<Kind> {
        val m = minuteOfDay(t)
        val r = mutableListOf<Kind>()
        if (p.dhikrOn && p.dhikrEvery > 0 && m % p.dhikrEvery == 0) r += Kind.DHIKR
        val s = salawatEvery(p, t)
        if (p.salawatOn && s > 0 && m % s == 0) r += Kind.SALAWAT
        return r
    }

    private fun nextPeriodic(p: Prefs, now: Long): Long? {
        var t = (now / MIN + 1) * MIN
        repeat(24 * 60 + 2) {
            if (periodicDue(p, t).isNotEmpty()) return t
            t += MIN
        }
        return null
    }

    fun nextTime(p: Prefs, now: Long): Long {
        val c = mutableListOf<Long>()
        nextPeriodic(p, now)?.let { c += it }
        val today = startOfDay(now)
        for (d in listOf(today, plusDays(today, 1))) fixedEvents(p, d).forEach { if (it.time > now + 1000) c += it.time }
        return c.minOrNull() ?: (now + 15 * MIN)
    }

    /** everything due at the (minute-rounded) time t */
    fun dueAt(p: Prefs, t: Long): List<Ev> {
        val fixed = fixedEvents(p, startOfDay(t)).filter { abs(it.time - t) < 90_000L }
        if (fixed.any { it.kind == Kind.TAKBIR }) return fixed
        return fixed + periodicDue(p, t).map { Ev(t, it) }
    }

    /** periodic reminders are silent while sleeping and during each prayer */
    fun muted(p: Prefs, t: Long): Boolean = muteReason(p, t) != null

    fun muteReason(p: Prefs, t: Long): String? {
        val pr = Prayer.times(p, startOfDay(t))
        val m = minuteOfDay(t)
        if (p.sleepOn) {
            val end = if (p.sleepUntilFajr) minuteOfDay(pr[0]) else p.sleepEndMin
            val s = p.sleepStartMin
            val inSleep = if (s > end) (m >= s || m < end) else (m in s until end)
            if (inSleep) return "وقت النوم"
        }
        for (i in 0 until 5) {
            val a = pr[i] + p.muteAfter(i) * MIN
            val b = a + p.muteFor(i) * MIN
            if (t in a until b) return "وقت صلاة ${Prayer.names[i]}"
        }
        return null
    }

    fun nextPrayer(p: Prefs, now: Long): Pair<Int, Long> {
        val today = startOfDay(now)
        val pr = Prayer.times(p, today)
        pr.forEachIndexed { i, t -> if (t > now) return Pair(i, t) }
        return Pair(0, Prayer.times(p, plusDays(today, 1))[0])
    }
}

object Fmt {
    private val ar = Locale("ar")
    fun time(t: Long): String = SimpleDateFormat("h:mm a", ar).format(Date(t))
    fun remaining(ms: Long): String {
        val m = (ms / 60_000L).toInt().coerceAtLeast(0)
        val h = m / 60
        val mm = m % 60
        return if (h > 0) "$h ساعة و $mm دقيقة" else "$mm دقيقة"
    }
    fun hm(min: Int): String {
        val c = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, min / 60); set(Calendar.MINUTE, min % 60) }
        return SimpleDateFormat("h:mm a", ar).format(c.time)
    }
}
