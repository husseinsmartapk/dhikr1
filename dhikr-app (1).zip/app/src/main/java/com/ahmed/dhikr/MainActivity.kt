package com.ahmed.dhikr

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.util.Calendar

class MainActivity : ComponentActivity() {
    val tab = mutableIntStateOf(0)
    val volKey = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DhikrService.channels(this)
        setContent {
            val dark = isSystemInDarkTheme()
            val scheme = if (dark) darkColorScheme(
                primary = Color(0xFF7FD3B0), onPrimary = Color(0xFF0B2A20),
                secondary = Color(0xFFE2C275),
                background = Color(0xFF0F1A16), surface = Color(0xFF17251F),
                onBackground = Color(0xFFE8EFEA), onSurface = Color(0xFFE8EFEA)
            ) else lightColorScheme(
                primary = Color(0xFF1F6B52), onPrimary = Color.White,
                secondary = Color(0xFF9A7724),
                background = Color(0xFFF6F3EA), surface = Color.White,
                onBackground = Color(0xFF1B2420), onSurface = Color(0xFF1B2420)
            )
            MaterialTheme(colorScheme = scheme) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    AppRoot(this@MainActivity)
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (tab.intValue == 1 && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            volKey.intValue = volKey.intValue + 1
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}

private fun refresh(ctx: Context) {
    if (Prefs(ctx).enabled) DhikrService.start(ctx) else Scheduler.schedule(ctx)
    DhikrWidget.updateAll(ctx)
}

@Composable
fun AppRoot(act: MainActivity) {
    val labels = listOf("الرئيسية", "العداد", "الأذكار", "الإعدادات")
    val icons = listOf("🕌", "📿", "📖", "⚙️")
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar {
                labels.forEachIndexed { i, s ->
                    NavigationBarItem(
                        selected = act.tab.intValue == i,
                        onClick = { act.tab.intValue = i },
                        icon = { Text(icons[i], fontSize = 20.sp) },
                        label = { Text(s) }
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (act.tab.intValue) {
                0 -> HomeScreen()
                1 -> CounterScreen(act)
                2 -> AdhkarScreen()
                else -> SettingsScreen()
            }
        }
    }
}

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
fun Bar(label: String, v: Int, target: Int) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text("${v.coerceAtMost(target)} / $target", fontWeight = FontWeight.Bold)
        }
        LinearProgressIndicator(
            progress = { (v.toFloat() / target).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
        )
    }
}

// ============================================================ HOME
@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val p = remember { Prefs(ctx) }
    var enabled by remember { mutableStateOf(p.enabled) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { now = System.currentTimeMillis(); delay(15_000) }
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        p.enabled = true; enabled = true; DhikrService.start(ctx)
    }
    val next = Engine.nextPrayer(p, now)
    val times = Prayer.times(p, Engine.startOfDay(now))
    val mute = Engine.muteReason(p, now)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(
            Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
        ) {
            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("الصلاة القادمة", color = MaterialTheme.colorScheme.onPrimary, fontSize = 15.sp)
                Text(Prayer.names[next.first], color = MaterialTheme.colorScheme.onPrimary, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                Text(Fmt.time(next.second), color = MaterialTheme.colorScheme.onPrimary, fontSize = 20.sp)
                Text("باقي " + Fmt.remaining(next.second - now), color = MaterialTheme.colorScheme.onPrimary, fontSize = 15.sp)
                Text("📍 " + p.placeName, color = MaterialTheme.colorScheme.onPrimary, fontSize = 13.sp)
            }
        }

        Button(
            onClick = {
                if (enabled) {
                    p.enabled = false; enabled = false; DhikrService.stop(ctx)
                } else if (Build.VERSION.SDK_INT >= 33 &&
                    ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    p.enabled = true; enabled = true; DhikrService.start(ctx)
                }
            },
            modifier = Modifier.fillMaxWidth().height(64.dp),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = if (enabled) Color(0xFFB3412E) else MaterialTheme.colorScheme.primary)
        ) { Text(if (enabled) "إيقاف التذكير" else "تشغيل التذكير", fontSize = 20.sp, color = Color.White) }

        if (enabled) Text(
            if (mute != null) "🔕 صامت الآن: $mute" else "🔔 يعمل الآن",
            Modifier.fillMaxWidth(), textAlign = TextAlign.Center
        )

        OutlinedButton(onClick = { DhikrService.start(ctx, DhikrService.ACTION_TEST) }, modifier = Modifier.fillMaxWidth()) {
            Text("🔊 تجربة الصوت")
        }

        Section("مواقيت اليوم") {
            times.forEachIndexed { i, t ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    val bold = if (i == next.first && t > now) FontWeight.Bold else FontWeight.Normal
                    Text(Prayer.names[i], fontWeight = bold)
                    Text(Fmt.time(t), fontWeight = bold)
                }
            }
            Text("طريقة الحساب: أم القرى", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
        }

        Section("ورد اليوم") {
            Bar("الاستغفار", p.count("istighfar"), 100)
            Bar("الصلاة على النبي ﷺ", p.count("salawat"), 100)
            if (p.wirdComplete()) Text("أحسنت! أكملت وردك اليوم 🌿", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }

        Section("إحصائية") {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(""); Text("اليوم", fontWeight = FontWeight.Bold); Text("الأسبوع", fontWeight = FontWeight.Bold)
            }
            StatRow(p, "استغفار (العداد)", "istighfar")
            StatRow(p, "صلاة على النبي (العداد)", "salawat")
            StatRow(p, "صلاة على النبي (تلقائي)", "auto_salawat")
            StatRow(p, "أذكار (تلقائي)", "auto_dhikr")
        }

        HealthCards()
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun StatRow(p: Prefs, label: String, key: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, Modifier.weight(1f))
        Text("${p.count(key)}", Modifier.width(60.dp), textAlign = TextAlign.Center)
        Text("${p.weekSum(key)}", Modifier.width(60.dp), textAlign = TextAlign.Center)
    }
}

@Composable
fun HealthCards() {
    val ctx = LocalContext.current
    val p = remember { Prefs(ctx) }
    val pm = ctx.getSystemService(PowerManager::class.java)!!
    var ignoring by remember { mutableStateOf(pm.isIgnoringBatteryOptimizations(ctx.packageName)) }
    var exact by remember { mutableStateOf(Scheduler.canExact(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000)
            ignoring = pm.isIgnoringBatteryOptimizations(ctx.packageName)
            exact = Scheduler.canExact(ctx)
        }
    }
    if (!p.ttsOk) Warn(
        "صوت النطق العربي غير جاهز",
        "افتح إعدادات (تحويل النص إلى كلام)، اختر محرك Google، ثم نزّل اللغة العربية. أو اختر ملفات صوت من الإعدادات.",
        "فتح إعدادات النطق"
    ) {
        try { ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS")) } catch (e: Exception) { }
    }
    if (!exact && Build.VERSION.SDK_INT >= 31) Warn(
        "اسمح بالتنبيهات الدقيقة",
        "بدونها ممكن تتأخر التذكيرات بضع دقائق.",
        "السماح"
    ) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName)))
        } catch (e: Exception) { }
    }
    if (!ignoring) Warn(
        "مهم: استثناء التطبيق من توفير البطارية",
        "عشان الجوال ما يقفل التطبيق في الخلفية. اضغط الزر واختر (سماح).",
        "استثناء الآن"
    ) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName)))
        } catch (e: Exception) {
            try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e2: Exception) { }
        }
    }
    Section("لو التطبيق يوقف لوحده") {
        Text("• سامسونج: الإعدادات ← البطارية ← حدود استخدام الخلفية ← أضف «ذِكر» إلى (التطبيقات التي لا تدخل في وضع السكون أبداً).", fontSize = 14.sp)
        Text("• شاومي: معلومات التطبيق ← توفير البطارية ← (بلا قيود)، وفعّل (التشغيل التلقائي).", fontSize = 14.sp)
        Text("• هواوي: الإعدادات ← البطارية ← تشغيل التطبيقات ← «ذِكر» ← إدارة يدوية، وفعّل الخيارات الثلاثة.", fontSize = 14.sp)
        OutlinedButton(onClick = {
            try {
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)))
            } catch (e: Exception) { }
        }) { Text("فتح معلومات التطبيق") }
    }
}

@Composable
fun Warn(title: String, body: String, btn: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE9C7))
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("⚠️ $title", fontWeight = FontWeight.Bold, color = Color(0xFF5A3B00))
            Text(body, color = Color(0xFF5A3B00), fontSize = 14.sp)
            Button(onClick = onClick) { Text(btn) }
        }
    }
}

// ============================================================ COUNTER
@Composable
fun CounterScreen(act: MainActivity) {
    val ctx = LocalContext.current
    val p = remember { Prefs(ctx) }
    var kind by remember { mutableIntStateOf(0) }
    val key = if (kind == 0) "istighfar" else "salawat"
    var n by remember(kind) { mutableIntStateOf(p.count(key)) }
    val add = {
        p.addCount(key)
        n = p.count(key)
        if (n == 100) Toast.makeText(ctx, "أحسنت! أكملت المئة 🌿", Toast.LENGTH_LONG).show()
    }
    val vk = act.volKey.intValue
    var lastVk by remember { mutableIntStateOf(vk) }
    LaunchedEffect(vk) {
        if (vk != lastVk) { lastVk = vk; add() }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Seg("الاستغفار", kind == 0, Modifier.weight(1f)) { kind = 0 }
            Seg("الصلاة على النبي ﷺ", kind == 1, Modifier.weight(1f)) { kind = 1 }
        }
        Text(
            if (kind == 0) Content.ISTIGHFAR else Content.SALAWAT,
            fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
            color = MaterialTheme.colorScheme.onBackground
        )
        Box(
            Modifier.size(250.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary).clickable { add() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$n", fontSize = 72.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimary)
                Text("من 100", fontSize = 18.sp, color = MaterialTheme.colorScheme.onPrimary)
            }
        }
        if (n >= 100) Text("أحسنت! أكملت وردك 🌿", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Text("اضغط على الدائرة، أو استخدم زر الصوت للعدّ", fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground)
        OutlinedButton(onClick = { p.setCount(key, 0); n = 0 }) { Text("تصفير العداد") }
    }
}

@Composable
fun Seg(text: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick, modifier = modifier, contentPadding = PaddingValues(6.dp)) { Text(text, textAlign = TextAlign.Center) }
    } else {
        OutlinedButton(onClick = onClick, modifier = modifier, contentPadding = PaddingValues(6.dp)) { Text(text, textAlign = TextAlign.Center) }
    }
}

// ============================================================ ADHKAR
@Composable
fun AdhkarScreen() {
    val ctx = LocalContext.current
    val p = remember { Prefs(ctx) }
    var evening by remember { mutableStateOf(Calendar.getInstance().get(Calendar.HOUR_OF_DAY) >= 12) }
    var tick by remember { mutableIntStateOf(0) }
    val list = if (evening) Content.EVENING else Content.MORNING
    val set = if (evening) "e" else "m"

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Seg("أذكار الصباح", !evening, Modifier.weight(1f)) { evening = false }
            Seg("أذكار المساء", evening, Modifier.weight(1f)) { evening = true }
        }
        LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            itemsIndexed(list) { i, z ->
                val done = remember(tick, evening) { p.zikrCount(set, i) }
                val complete = done >= z.count
                Card(
                    Modifier.fillMaxWidth().clickable {
                        if (!complete) { p.setZikrCount(set, i, done + 1); tick++ }
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (complete) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (z.note.isNotEmpty()) Text(z.note, color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Text(z.text, fontSize = 19.sp, lineHeight = 34.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("التكرار: ${z.count}", fontSize = 14.sp)
                            Text(
                                if (complete) "تم ✓" else "$done / ${z.count}",
                                fontWeight = FontWeight.Bold,
                                color = if (complete) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
            item {
                Text(
                    "المصدر: حصن المسلم. اضغط على الذكر لعدّه. يُنصح بمراجعة النصوص مع نسختك المطبوعة.",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(8.dp)
                )
                OutlinedButton(onClick = {
                    list.indices.forEach { p.setZikrCount(set, it, 0) }; tick++
                }) { Text("إعادة البدء") }
            }
        }
    }
}
