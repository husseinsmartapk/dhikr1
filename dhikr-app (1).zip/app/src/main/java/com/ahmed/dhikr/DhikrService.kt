package com.ahmed.dhikr

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class DhikrService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_TICK = "com.ahmed.dhikr.TICK"
        const val ACTION_TEST = "com.ahmed.dhikr.TEST"
        const val ACTION_REFRESH = "com.ahmed.dhikr.REFRESH"
        const val CH_SVC = "svc"
        const val CH_REM = "rem"
        const val NID = 1

        fun start(ctx: Context, action: String = ACTION_REFRESH) {
            val i = Intent(ctx, DhikrService::class.java).setAction(action)
            try {
                ContextCompat.startForegroundService(ctx, i)
            } catch (e: Exception) {
                Scheduler.schedule(ctx)
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, DhikrService::class.java))
            Scheduler.schedule(ctx)
            DhikrWidget.updateAll(ctx)
        }

        fun channels(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)!!
            nm.createNotificationChannel(NotificationChannel(CH_SVC, "تشغيل ذِكر", NotificationManager.IMPORTANCE_LOW).apply { setShowBadge(false) })
            nm.createNotificationChannel(NotificationChannel(CH_REM, "التذكيرات", NotificationManager.IMPORTANCE_DEFAULT).apply { setSound(null, null) })
        }
    }

    private enum class Cat { SALAWAT, DHIKR, TAKBIR, OTHER }
    private data class Item(val text: String, val cat: Cat)
    private enum class Out { NONE, VIBRATE, SOUND }

    private lateinit var p: Prefs
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsFailed = false
    private val queue = ArrayDeque<Item>()
    private var busy = false
    private val h = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var focus: AudioFocusRequest? = null
    private val speechAttrs: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        p = Prefs(this)
        channels(this)
        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            p.ttsOk = false
            ttsFailed = true
            h.post { playNext() }
            return
        }
        val r = tts?.setLanguage(Locale("ar")) ?: TextToSpeech.LANG_NOT_SUPPORTED
        p.ttsOk = r >= TextToSpeech.LANG_AVAILABLE
        tts?.setAudioAttributes(speechAttrs)
        tts?.setSpeechRate(0.9f)
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { h.post { finished() } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { h.post { finished() } }
            override fun onError(utteranceId: String?, errorCode: Int) { h.post { finished() } }
        })
        ttsReady = true
        h.post { playNext() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        val action = intent?.action
        if (action == ACTION_TEST) {
            enqueue(Item(Content.SALAWAT, Cat.SALAWAT))
        } else if (!p.enabled) {
            stopAll()
            return START_NOT_STICKY
        }
        if (action == ACTION_TICK) handleTick()
        Scheduler.schedule(this)
        goForeground()
        DhikrWidget.updateAll(this)
        return if (p.enabled) START_STICKY else START_NOT_STICKY
    }

    private fun goForeground() {
        val (i, t) = Engine.nextPrayer(p, System.currentTimeMillis())
        val txt = "الصلاة القادمة: ${Prayer.names[i]} ${Fmt.time(t)}"
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CH_SVC)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(if (p.enabled) "ذِكر يعمل" else "ذِكر")
            .setContentText(txt)
            .setOngoing(true)
            .setContentIntent(pi)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, NID, n, type)
    }

    private fun stopAll() {
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        Scheduler.schedule(this)
        DhikrWidget.updateAll(this)
        stopSelf()
    }

    private fun handleTick() {
        val now = System.currentTimeMillis()
        val key = ((now + 30_000L) / Engine.MIN) * Engine.MIN
        if (key == p.lastHandled) return
        p.lastHandled = key
        val muted = Engine.muted(p, key)
        for (e in Engine.dueAt(p, key).sortedBy { it.kind.ordinal }) {
            when (e.kind) {
                Engine.Kind.TAKBIR -> {
                    enqueue(Item(Content.TAKBIR, Cat.TAKBIR))
                    notifyRem(10 + e.idx, "حان وقت صلاة ${Prayer.names[e.idx]}", Content.TAKBIR)
                }
                Engine.Kind.MORNING -> {
                    notifyRem(20, "أذكار الصباح", "حان وقت أذكار الصباح، افتح التطبيق لقراءتها")
                    if (!muted) enqueue(Item("حان وقت أذكار الصباح", Cat.OTHER))
                }
                Engine.Kind.EVENING -> {
                    notifyRem(21, "أذكار المساء", "حان وقت أذكار المساء، افتح التطبيق لقراءتها")
                    if (!muted) enqueue(Item("حان وقت أذكار المساء", Cat.OTHER))
                }
                Engine.Kind.WIRD -> if (!p.wirdComplete()) {
                    notifyRem(22, "وردك اليومي", wirdText())
                    if (!muted) enqueue(Item("تذكير بوردك اليومي، مئة استغفار، ومئة صلاة على النبي", Cat.OTHER))
                }
                Engine.Kind.WIRD_CHECK -> if (!p.wirdComplete()) {
                    notifyRem(23, "باقي شيء من وردك", wirdText())
                    if (!muted) enqueue(Item("باقي شيء من وردك اليوم", Cat.OTHER))
                }
                Engine.Kind.KAHF -> {
                    notifyRem(24, "يوم الجمعة", "لا تنس قراءة سورة الكهف، والإكثار من الصلاة على النبي صلى الله عليه وسلم")
                    if (!muted) enqueue(Item("لا تنس قراءة سورة الكهف", Cat.OTHER))
                }
                Engine.Kind.DHIKR -> if (!muted) {
                    val i = p.dhikrIndex % Content.DHIKR.size
                    p.dhikrIndex = i + 1
                    enqueue(Item(Content.DHIKR[i], Cat.DHIKR))
                    p.addCount("auto_dhikr")
                }
                Engine.Kind.SALAWAT -> if (!muted) {
                    enqueue(Item(Content.SALAWAT, Cat.SALAWAT))
                    p.addCount("auto_salawat")
                }
            }
        }
    }

    private fun wirdText(): String =
        "الاستغفار ${p.count("istighfar")} من 100 — الصلاة على النبي ${p.count("salawat")} من 100"

    // ---------------- playback ----------------
    private fun enqueue(item: Item) {
        queue.addLast(item)
        if (!busy) playNext()
    }

    private fun playNext() {
        if (busy) return
        val item = queue.removeFirstOrNull()
        if (item == null) {
            releaseFocus()
            if (!p.enabled) stopAll()
            return
        }
        when (output()) {
            Out.NONE -> { h.post { playNext() }; return }
            Out.VIBRATE -> {
                vibrate()
                busy = true
                h.postDelayed({ busy = false; playNext() }, 1500)
                return
            }
            Out.SOUND -> {}
        }
        val uri = when (item.cat) {
            Cat.SALAWAT -> p.uriSalawat
            Cat.TAKBIR -> p.uriTakbir
            Cat.DHIKR -> p.uriDhikr
            Cat.OTHER -> null
        }
        busy = true
        requestFocus()
        if (uri != null && playUri(uri)) return
        if (ttsFailed) { finished(); return }
        if (!ttsReady) {
            busy = false
            queue.addFirst(item)
            return
        }
        val b = Bundle()
        b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, p.volume)
        val r = tts?.speak(item.text, TextToSpeech.QUEUE_FLUSH, b, "u" + System.nanoTime())
        if (r != TextToSpeech.SUCCESS) finished()
    }

    private fun finished() {
        busy = false
        h.postDelayed({ playNext() }, 2000)
    }

    private fun playUri(s: String): Boolean {
        return try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(speechAttrs)
            mp.setDataSource(this, Uri.parse(s))
            mp.setOnCompletionListener { m -> m.release(); player = null; finished() }
            mp.setOnErrorListener { m, _, _ -> m.release(); player = null; finished(); true }
            mp.prepare()
            val vol = p.volume
            mp.setVolume(vol * 0.3f, vol * 0.3f)
            mp.start()
            player = mp
            for (k in 1..5) {
                h.postDelayed({
                    try { val f = vol * (0.3f + 0.14f * k); player?.setVolume(f, f) } catch (e: Exception) { }
                }, k * 250L)
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun output(): Out {
        val am = getSystemService(AudioManager::class.java)!!
        if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION) return Out.NONE
        if (am.ringerMode == AudioManager.RINGER_MODE_SILENT) return Out.NONE
        if (p.mode == 1 || am.ringerMode == AudioManager.RINGER_MODE_VIBRATE) return Out.VIBRATE
        if (p.mode == 2 && !headset(am)) return Out.NONE
        return Out.SOUND
    }

    private fun headset(am: AudioManager): Boolean {
        val types = setOf(
            AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET,
            AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_USB_HEADSET, 26 /* TYPE_BLE_HEADSET */
        )
        return am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { it.type in types }
    }

    private fun vibrate() {
        try {
            vibrator().vibrate(VibrationEffect.createWaveform(longArrayOf(0, 120, 120, 120), -1))
        } catch (e: Exception) { }
    }

    @Suppress("DEPRECATION")
    private fun vibrator(): Vibrator =
        if (Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java)!!.defaultVibrator
        else getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

    private fun requestFocus() {
        val am = getSystemService(AudioManager::class.java)!!
        val f = focus ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(speechAttrs).build().also { focus = it }
        am.requestAudioFocus(f)
    }

    private fun releaseFocus() {
        val f = focus ?: return
        getSystemService(AudioManager::class.java)!!.abandonAudioFocusRequest(f)
    }

    @SuppressLint("MissingPermission")
    private fun notifyRem(id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val pi = PendingIntent.getActivity(this, id, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CH_REM)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        NotificationManagerCompat.from(this).notify(id, n)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { player?.release() } catch (e: Exception) { }
        tts?.shutdown()
        releaseFocus()
        super.onDestroy()
    }
}
