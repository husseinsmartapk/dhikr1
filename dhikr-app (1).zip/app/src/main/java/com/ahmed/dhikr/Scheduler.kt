package com.ahmed.dhikr

import android.annotation.SuppressLint
import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import android.widget.RemoteViews

object Scheduler {
    private fun alarmIntent(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 7,
        Intent(ctx, AlarmReceiver::class.java).setAction("com.ahmed.dhikr.ALARM"),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    fun canExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(AlarmManager::class.java)!!
        return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
    }

    fun schedule(ctx: Context) {
        val p = Prefs(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java)!!
        val pi = alarmIntent(ctx)
        if (!p.enabled) { am.cancel(pi); return }
        val t = Engine.nextTime(p, System.currentTimeMillis())
        try {
            if (canExact(ctx)) {
                if (p.precise) {
                    val show = PendingIntent.getActivity(ctx, 8, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                    am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
                }
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, pi)
        }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        DhikrService.start(ctx, DhikrService.ACTION_TICK)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (Prefs(ctx).enabled) DhikrService.start(ctx, DhikrService.ACTION_REFRESH) else Scheduler.schedule(ctx)
        DhikrWidget.updateAll(ctx)
    }
}

class DhikrWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        updateAll(ctx)
    }

    companion object {
        fun updateAll(ctx: Context) {
            try {
                val mgr = AppWidgetManager.getInstance(ctx)
                val ids = mgr.getAppWidgetIds(ComponentName(ctx, DhikrWidget::class.java))
                if (ids.isEmpty()) return
                val p = Prefs(ctx)
                val (i, t) = Engine.nextPrayer(p, System.currentTimeMillis())
                val rv = RemoteViews(ctx.packageName, R.layout.widget)
                rv.setTextViewText(R.id.w_prayer, "${Prayer.names[i]}  ${Fmt.time(t)}")
                rv.setTextViewText(R.id.w_state, if (p.enabled) "ذِكر يعمل" else "ذِكر متوقف")
                val pi = PendingIntent.getActivity(ctx, 3, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
                rv.setOnClickPendingIntent(R.id.w_root, pi)
                mgr.updateAppWidget(ids, rv)
            } catch (e: Exception) {
            }
        }
    }
}

object Loc {
    @SuppressLint("MissingPermission")
    fun fetch(ctx: Context, done: (Boolean) -> Unit) {
        val lm = ctx.getSystemService(LocationManager::class.java)!!
        val p = Prefs(ctx)
        var finished = false
        fun save(l: Location?) {
            if (finished) return
            finished = true
            if (l == null) { done(false); return }
            p.lat = l.latitude; p.lng = l.longitude; p.placeName = "موقعي الحالي"
            done(true)
        }
        val last = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { pr -> try { lm.getLastKnownLocation(pr) } catch (e: Exception) { null } }
            .maxByOrNull { it.time }
        if (last != null) { save(last); return }
        val prov = if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) LocationManager.NETWORK_PROVIDER else LocationManager.GPS_PROVIDER
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                lm.getCurrentLocation(prov, null, ctx.mainExecutor) { l -> save(l) }
            } else {
                legacy(lm, prov) { l -> save(l) }
            }
        } catch (e: Exception) {
            save(null)
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun legacy(lm: LocationManager, prov: String, cb: (Location) -> Unit) {
        lm.requestSingleUpdate(prov, LocationListener { l -> cb(l) }, Looper.getMainLooper())
    }
}
