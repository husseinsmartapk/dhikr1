package com.ahmed.dhikr

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class Prefs(ctx: Context) {
    val sp: SharedPreferences = ctx.applicationContext.getSharedPreferences("dhikr", Context.MODE_PRIVATE)

    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun sb(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun si(k: String, v: Int) = sp.edit().putInt(k, v).apply()

    var enabled: Boolean
        get() = b("enabled", false)
        set(v) = sb("enabled", v)

    var salawatOn: Boolean
        get() = b("salawatOn", true)
        set(v) = sb("salawatOn", v)
    var salawatEvery: Int
        get() = i("salawatEvery", 5)
        set(v) = si("salawatEvery", v)
    var fridaySalawatEvery: Int
        get() = i("fridaySalawatEvery", 3)
        set(v) = si("fridaySalawatEvery", v)
    var dhikrOn: Boolean
        get() = b("dhikrOn", true)
        set(v) = sb("dhikrOn", v)
    var dhikrEvery: Int
        get() = i("dhikrEvery", 10)
        set(v) = si("dhikrEvery", v)
    var takbirOn: Boolean
        get() = b("takbirOn", true)
        set(v) = sb("takbirOn", v)

    fun muteAfter(p: Int): Int = i("muteAfter$p", 15)
    fun setMuteAfter(p: Int, v: Int) = si("muteAfter$p", v)
    fun muteFor(p: Int): Int = i("muteFor$p", 20)
    fun setMuteFor(p: Int, v: Int) = si("muteFor$p", v)

    var sleepOn: Boolean
        get() = b("sleepOn", true)
        set(v) = sb("sleepOn", v)
    var sleepStartMin: Int
        get() = i("sleepStartMin", 23 * 60)
        set(v) = si("sleepStartMin", v)
    var sleepUntilFajr: Boolean
        get() = b("sleepUntilFajr", true)
        set(v) = sb("sleepUntilFajr", v)
    var sleepEndMin: Int
        get() = i("sleepEndMin", 5 * 60)
        set(v) = si("sleepEndMin", v)

    /** 0 = sound, 1 = vibrate only, 2 = headphones only */
    var mode: Int
        get() = i("mode", 0)
        set(v) = si("mode", v)
    var volume: Float
        get() = sp.getFloat("volume", 0.8f)
        set(v) = sp.edit().putFloat("volume", v).apply()
    var precise: Boolean
        get() = b("precise", true)
        set(v) = sb("precise", v)

    var lat: Double
        get() = java.lang.Double.longBitsToDouble(sp.getLong("lat", java.lang.Double.doubleToRawLongBits(25.3833)))
        set(v) = sp.edit().putLong("lat", java.lang.Double.doubleToRawLongBits(v)).apply()
    var lng: Double
        get() = java.lang.Double.longBitsToDouble(sp.getLong("lng", java.lang.Double.doubleToRawLongBits(49.5867)))
        set(v) = sp.edit().putLong("lng", java.lang.Double.doubleToRawLongBits(v)).apply()
    var placeName: String
        get() = sp.getString("placeName", "الأحساء") ?: "الأحساء"
        set(v) = sp.edit().putString("placeName", v).apply()

    var wirdOn: Boolean
        get() = b("wirdOn", true)
        set(v) = sb("wirdOn", v)
    var wirdMin: Int
        get() = i("wirdMin", 20 * 60 + 30)
        set(v) = si("wirdMin", v)
    var morningOn: Boolean
        get() = b("morningOn", true)
        set(v) = sb("morningOn", v)
    var eveningOn: Boolean
        get() = b("eveningOn", true)
        set(v) = sb("eveningOn", v)
    var kahfOn: Boolean
        get() = b("kahfOn", true)
        set(v) = sb("kahfOn", v)

    var uriSalawat: String?
        get() = sp.getString("uriSalawat", null)
        set(v) = sp.edit().putString("uriSalawat", v).apply()
    var uriTakbir: String?
        get() = sp.getString("uriTakbir", null)
        set(v) = sp.edit().putString("uriTakbir", v).apply()
    var uriDhikr: String?
        get() = sp.getString("uriDhikr", null)
        set(v) = sp.edit().putString("uriDhikr", v).apply()

    var lastHandled: Long
        get() = sp.getLong("lastHandled", 0L)
        set(v) = sp.edit().putLong("lastHandled", v).apply()
    var dhikrIndex: Int
        get() = i("dhikrIndex", 0)
        set(v) = si("dhikrIndex", v)
    var ttsOk: Boolean
        get() = b("ttsOk", true)
        set(v) = sb("ttsOk", v)

    // ---------- daily counters / stats ----------
    fun dayKey(t: Long = System.currentTimeMillis()): String =
        SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(t))

    fun count(name: String, day: String = dayKey()): Int = sp.getInt("c_${name}_$day", 0)
    fun setCount(name: String, v: Int, day: String = dayKey()) = sp.edit().putInt("c_${name}_$day", v).apply()
    fun addCount(name: String, n: Int = 1) { val d = dayKey(); setCount(name, count(name, d) + n, d) }
    fun weekSum(name: String): Int {
        val now = System.currentTimeMillis()
        return (0..6).sumOf { count(name, dayKey(now - it * 86_400_000L)) }
    }
    fun wirdComplete(): Boolean = count("istighfar") >= 100 && count("salawat") >= 100

    fun zikrCount(set: String, idx: Int): Int = sp.getInt("z_${set}_${idx}_${dayKey()}", 0)
    fun setZikrCount(set: String, idx: Int, v: Int) = sp.edit().putInt("z_${set}_${idx}_${dayKey()}", v).apply()
}
